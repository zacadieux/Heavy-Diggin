Heavy Diggin 2.48.0 for Windows (64-bit)

Run HeavyDiggin.exe. Nothing to install: settings and saves go in %APPDATA%\HeavyDiggin.
It needs an OpenGL graphics driver: the usual driver for your graphics card has one.
If Windows SmartScreen says it doesn't recognise the app, choose "More info" and "Run anyway".
Multiplayer uses TCP port 27960: allow it through the Windows firewall when it asks, to host.

Controls and everything else: see the README.md that comes with the game's source, or press Esc in the game.
